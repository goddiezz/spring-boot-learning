package com.potato.boot.mybatis.mapper;

import com.potato.boot.mybatis.domain.Teacher1;

/**
 * @author loorzve
 */
public interface Teacher1Mapper {
    Teacher1 getTeacherOneByOne(int teacherId);
}