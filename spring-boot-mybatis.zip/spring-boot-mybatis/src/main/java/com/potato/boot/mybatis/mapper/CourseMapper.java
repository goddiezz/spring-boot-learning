package com.potato.boot.mybatis.mapper;

import com.potato.boot.mybatis.domain.Course;

public interface CourseMapper {

}